# Start to run tests after the application installed
# This is an example simply start and close the application
push-location $PSScriptRoot
$exit_code = 0
$script_name = $myinvocation.mycommand.name
# You can use the following variables to construct file path
# Root folder
$root_dir = "$PSScriptRoot\..\.."
# Bin folder
$bin_dir = "$root_dir\bin"
# Log folder
$log_dir = "$root_dir\logs"

$log_file = "$log_dir\$script_name.log"

if(-not (test-path -path $log_dir )) {
    new-item -itemtype directory -path $log_dir
}

Function log {
   Param ([string]$log_string)
   write-host $log_string
   add-content $log_file -value $log_string
}

# Launch the app
# For example: 
#    - If your application is under bin folder: Start-Process -FilePath "$bin_dir\MyApp.exe"
#    - Use environment variable if need: Start-Process -FilePath "$env:comspec" -ArgumentList "/c dir `"%systemdrive%\program files`""
log("Launch Application")
$exePath = "C:\Program Files\Test Base M365\DigitalClock\DigitalClock.exe"
Start-Process -FilePath $exePath

$PROCESS_NAME = "DigitalClock"
if (Get-Process -Name $PROCESS_NAME) {
    $exit_code = 0
    log("Launch successfully $PROCESS_NAME as $exit_code")         
}
else {
    $exit_code = 1
    log("App Launch failed as $exit_code")    
}

Start-Sleep -Seconds 3

 # Verify the Name of the App
$myProcess = (Get-Process -Name $PROCESS_NAME)

if ($myProcess.ProcessName -eq 'DigitalClock') {
    $exit_code = 0
    log("ProcessName: $PROCESS_NAME is running") 
}
else {
    $exit_code = 1
    log("ProcessName: $PROCESS_NAME not found") 
}

 # Verify the Window title of the App
 if ($myProcess.MainWindowTitle -eq 'Test Base M365 Sample App') {
    $exit_code = 0
    log("MainWindowTitle: $($myProcess.MainWindowTitle) is valid") 
 }
 else {
    $exit_code = 1
    log("MainWindowTitle: " + $myProcess.MainWindowTitle + " not valid") 
 }

 # Close the app
 if ($myProcess.CloseMainWindow()) {
    $exit_code = 0
    log("App closed successfully")
 }
 else {
    $exit_code = 1
    log("App close failed")
 }

log("Functional script finished as $exit_code")
pop-location
exit $exit_code
